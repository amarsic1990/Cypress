import "@cypress/code-coverage/support";
import "./commands";

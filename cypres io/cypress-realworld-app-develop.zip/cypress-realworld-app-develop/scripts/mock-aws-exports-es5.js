// mock aws-exports-es5.js

const awsmobile = {
  aws_cognito_region: "",
  aws_user_pools_id: "",
};

exports.default = awsmobile;

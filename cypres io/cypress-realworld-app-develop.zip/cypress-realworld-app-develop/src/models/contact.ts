export interface Contact {
  id: string;
  uuid: string;
  userId: string;
  contactUserId: string;
  createdAt: Date;
  modifiedAt: Date;
}

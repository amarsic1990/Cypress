export interface Like {
  id: string;
  uuid: string;
  userId: string;
  transactionId: string;
  createdAt: Date;
  modifiedAt: Date;
}
